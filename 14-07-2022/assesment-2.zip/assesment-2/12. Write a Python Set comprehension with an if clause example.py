##12. Write a Python Set comprehension with an if clause example
b={i if i%2==0 else i*100 for i in range(20)}
print(b)
